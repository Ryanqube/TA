/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package komputasi.kopi;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXCheckBox;
import com.jfoenix.controls.JFXRadioButton;
import com.jfoenix.controls.JFXTextArea;
import com.jfoenix.controls.JFXTextField;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ToggleGroup;

/**
 * FXML Controller class
 *
 * @author Nayang Albik B
 */
public class FXMLDocumentController implements Initializable {
    
    int jumlahmakan, jumlahminum;
    int hagatotal1,hagatotal2,hagatotal3,hagatotal4,hagatotal5,hagatotal6,hagatotal7,hagatotal8;
    String menu1, menu2, menu3, menu4,menu5,menu6,menu7,menu8;
    String menu="";
    String kasir="";
    String atasnama, tampilTotalBayar, ket;
    int harga, kembalian;
    int totalbayar, jmlUangBayar;
    
    
    @FXML
    private JFXCheckBox minggu1;
    @FXML
    private JFXCheckBox minggu2;
    @FXML
    private JFXCheckBox minggu3;
    @FXML
    private JFXCheckBox minggu4;
    @FXML
    private JFXTextField jumlah1;
    @FXML
    private JFXTextField jumlah2;
    @FXML
    private JFXTextField jumlah3;
    @FXML
    private JFXTextField jumlah4;
    @FXML
    private JFXButton btnhitung;
    @FXML
    private JFXButton btnhapus;
    @FXML
    private JFXTextField jumlahUang;
    @FXML
    private JFXTextArea hasilPesanan;
    @FXML
    private JFXRadioButton option1;
    @FXML
    private ToggleGroup satu;
    @FXML
    private JFXRadioButton option2;
    @FXML
    private JFXRadioButton option3;

    /**
     * Initializes the controller class.
     */
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void miu1(ActionEvent event) {
    }

    @FXML
    private void miu2(ActionEvent event) {
    }

    @FXML
    private void miu3(ActionEvent event) {
    }

    @FXML
    private void miu4(ActionEvent event) {
    }

    @FXML
    private void Hitung(ActionEvent event){
        int jumlahmakan=0;
        int jumlahjumlah = 0;
        if(option1.isSelected()){     
            harga = 30000;
            menu += option1.getText()+", ";
            jumlahmakan=Integer.parseInt(jumlah1.getText());
            hagatotal1=harga*jumlahmakan;
            System.out.println(hagatotal1);
        }
          if(option2.isSelected()){     
            harga = 15000;
            menu += option2.getText()+", ";
            jumlahmakan=Integer.parseInt(jumlah1.getText());
            hagatotal1=harga*jumlahmakan;
            System.out.println(hagatotal1);
        }
            if(option3.isSelected()){     
            harga = 45000;
            menu += option3.getText()+", ";
            jumlahmakan=Integer.parseInt(jumlah1.getText());
            hagatotal1=harga*jumlahmakan;
            System.out.println(hagatotal1);
        }
            
        totalbayar = hagatotal1+hagatotal2+hagatotal3+hagatotal4+hagatotal5+hagatotal6+hagatotal7+hagatotal8;
        tampilTotalBayar=String.valueOf(totalbayar);
        jumlahUang.setText(tampilTotalBayar);
    }

    @FXML
    private void Hapus(ActionEvent event) {
        jumlah1.setText("");
        
        jumlah2.setText("");
        
        jumlah3.setText("");
        
        jumlah4.setText("");
        
        option1.setSelected(false);
        
        option2.setSelected(false);
        
        option3.setSelected(false);
        
    }
    
}
